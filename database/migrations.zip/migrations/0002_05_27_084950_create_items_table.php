<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('items', function (Blueprint $table) {
            $table->string('kode_item')->primary(); // Example: BJU001
            $table->string('nama_item');
            $table->unsignedBigInteger('kategori_id');
            $table->unsignedBigInteger('subkategori_id')->nullable();
            $table->string('warna');
            $table->string('size');
            $table->integer('stok')->default(0);
            $table->integer('minimum_stok')->default(0);
            $table->timestamps();

            $table->foreign('kategori_id')->references('id')->on('categories')->onDelete('cascade');
            $table->foreign('subkategori_id')->references('id')->on('subcategories')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('items');
    }
};
